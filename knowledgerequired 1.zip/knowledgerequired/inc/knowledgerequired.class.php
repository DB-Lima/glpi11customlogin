<?php

class PluginKnowledgerequired
{

   static function beforeAdd(ITILSolution $solution)
   {
      global $DB;

      if (($solution->input['itemtype'] ?? '') !== 'Ticket') {
         return true;
      }

      $ticket_id = (int) ($solution->input['items_id'] ?? 0);

      if ($ticket_id <= 0) {
         return true;
      }

      $iterator = $DB->request([
         'SELECT' => 'id',
         'FROM' => 'glpi_knowbaseitems_items',
         'WHERE' => [
            'itemtype' => 'Ticket',
            'items_id' => $ticket_id
         ]
      ]);

      if (!count($iterator) > 0) {
         Session::addMessageAfterRedirect(
            "Favor, inserir uma base de conhecimento para solucionar o chamado.",
            false,
            WARNING
         );
         $solution->input = false;
         return false;
      }
   }



   static function beforeUpdate(ITILSolution $solution)
   {
      global $DB;

      if (($solution->input['itemtype'] ?? '') !== 'Ticket') {
         return true;
      }

      $ticket_id = (int) ($solution->input['items_id'] ?? 0);

      if ($ticket_id <= 0) {
         return true;
      }

      $iterator = $DB->request([
         'SELECT' => 'id',
         'FROM' => 'glpi_knowbaseitems_items',
         'WHERE' => [
            'itemtype' => 'Ticket',
            'items_id' => $solution->input['id']
         ]
      ]);

      if (!count($iterator) > 0) {
         Session::addMessageAfterRedirect(
            "Favor, inserir uma base de conhecimento para solucionar o chamado.",
            false,
            WARNING
         );
         $solution->input = false;
         return false;
      }

   }

}