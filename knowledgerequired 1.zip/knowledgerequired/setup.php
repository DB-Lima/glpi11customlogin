<?php

include_once __DIR__ . '/inc/knowledgerequired.class.php';

define('PLUGIN_KNOWLEDGEREQUIRED_VERSION', '0.0.1');

function plugin_init_knowledgerequired()
{
   global $PLUGIN_HOOKS;

   $PLUGIN_HOOKS['csrf_compliant']['knowledgerequired'] = true;

   // $PLUGIN_HOOKS['pre_item_add']['knowledgerequired'] = [
   //    'ITILSolution' => 'beforeAdd_teste'
   // ];

   $PLUGIN_HOOKS['pre_item_add']['knowledgerequired'] = [
      'ITILSolution' => ['PluginKnowledgerequired', 'beforeAdd']
   ];

   $PLUGIN_HOOKS['pre_item_update']['knowledgerequired'] = [
      'ITILSolution' => ['PluginKnowledgerequired', 'beforeUpdate']
   ];
}

function plugin_version_knowledgerequired()
{
   return [
      'name' => 'Knowledge Required',
      'version' => PLUGIN_KNOWLEDGEREQUIRED_VERSION,
      'author' => 'Wesley Carlos Severiano',
      'license' => 'GPLv2+',
      'homepage' => '',
      'requirements' => [
         'glpi' => [
            'min' => '10.0.0'
         ]
      ]
   ];
}

function plugin_knowledgerequired_check_prerequisites()
{
   return true;
}

function plugin_knowledgerequired_check_config()
{
   return true;
}

function plugin_knowledgerequired_install()
{
   return true;
}

function plugin_knowledgerequired_uninstall()
{
   return true;
}