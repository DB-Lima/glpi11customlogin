<?php
// plugins/blockstatus/hook.php

function beforeAdd_teste(CommonDBTM $item) {

   print_r('chamoooou beforeAdd_teste xxx');exit;

   return true;
}